# My Website

A modern website built with Next.js, React, TypeScript, and Tailwind CSS.

## Prerequisites

Before running this project, make sure you have the following installed:
- Node.js (version 20 or higher recommended)
- npm (comes with Node.js)

## Installation

1. Clone the repository (if you haven't already)
2. Navigate to the project directory:
   ```bash
   cd my-website
   ```

3. Install dependencies:
   ```bash
   npm install
   ```

## Running the Development Server

To start the development server with hot-reloading:

```bash
npm run dev
```

The website will be available at [http://localhost:3000](http://localhost:3000)

The development server includes:
- Hot module replacement (changes appear instantly)
- Fast refresh for React components
- Error overlay for debugging

## Building for Production

To create an optimized production build:

```bash
npm run build
```

This will generate optimized static files and server-side code in the `.next` directory.

## Running the Production Server

After building, you can start the production server:

```bash
npm start
```

The production server will run at [http://localhost:3000](http://localhost:3000)

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run lint` - Run ESLint for code quality

## Tech Stack

- **Framework**: Next.js 16
- **UI Library**: React 19
- **Language**: TypeScript
- **Styling**: Tailwind CSS 4
- **Icons**: Lucide React
- **Components**: Custom components with class-variance-authority

## Project Structure

```
my-website/
├── src/              # Source code
├── public/           # Static assets
├── components.json   # Component configuration
├── package.json      # Project dependencies
└── tsconfig.json     # TypeScript configuration
```

## Learn More

- [Next.js Documentation](https://nextjs.org/docs)
- [React Documentation](https://react.dev)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
