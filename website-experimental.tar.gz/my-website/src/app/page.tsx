
import Hero from "@/components/Hero";
import Resume from "@/components/Resume";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main className="flex flex-col min-h-screen">
      <Hero />
      <Resume />
      <Footer />
    </main>
  );
}
