
export default function Footer() {
    return (
        <footer className="w-full py-6 text-center text-sm text-muted-foreground mt-auto">
            <p>Disclaimer: This website was entirely vibed together!</p>
        </footer>
    );
}
