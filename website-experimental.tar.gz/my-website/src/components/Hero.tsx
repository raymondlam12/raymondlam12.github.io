
import { Github, Linkedin } from "lucide-react";

export default function Hero() {
  return (
    <section className="min-h-screen flex flex-col items-center justify-center relative bg-background text-foreground">
      <div className="absolute top-8 left-8 flex gap-4 z-20 animate-in fade-in slide-in-from-top-4 duration-1000">
        <a
          href="https://github.com"
          target="_blank"
          rel="noopener noreferrer"
          className="text-muted-foreground hover:text-foreground transition-colors hover:scale-110 transform duration-200"
          aria-label="GitHub Profile"
        >
          <Github className="w-6 h-6" />
        </a>
        <a
          href="https://linkedin.com"
          target="_blank"
          rel="noopener noreferrer"
          className="text-muted-foreground hover:text-foreground transition-colors hover:scale-110 transform duration-200"
          aria-label="LinkedIn Profile"
        >
          <Linkedin className="w-6 h-6" />
        </a>
      </div>

      <div className="text-center z-10 animate-in fade-in zoom-in duration-1000">
        <h1 className="text-6xl md:text-9xl font-bold tracking-tighter mb-4">
          Raymond
        </h1>
        <p className="text-xl md:text-2xl text-muted-foreground">
          Hi, I'm a software engineer currently working at LinkedIn. Let's chat!
        </p>
        <p className="text-sm md:text-base text-muted-foreground">
          Disclaimer: I vibed this together. I had fun. I'm sure it's not the best! :sweat-smile:
        </p>
      </div>

      <div className="absolute bottom-10 animate-bounce">
        <span className="text-sm text-muted-foreground">Scroll to explore</span>
        <div className="w-1 h-12 bg-border mx-auto mt-2 rounded-full relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1/2 bg-foreground/50 animate-[scroll_1.5s_infinite]" />
        </div>
      </div>
    </section>
  );
}
