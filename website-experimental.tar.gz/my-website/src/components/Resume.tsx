
export default function Resume() {
    return (
        <section className="min-h-screen py-20 px-8 max-w-4xl mx-auto flex flex-col justify-center">
            <h2 className="text-4xl font-bold mb-12 tracking-tight border-b pb-4">Resume</h2>

            <div className="space-y-12">
                <div className="relative pl-8 border-l-2 border-muted hover:border-primary/50 transition-colors duration-300">
                    <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-background border-2 border-primary" />

                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2">
                        <h3 className="text-2xl font-semibold">AI Prompter</h3>
                        <span className="text-sm text-muted-foreground font-mono bg-secondary px-2 py-1 rounded">
                            Present
                        </span>
                    </div>

                    <div className="text-lg text-primary mb-4">Stealth Startup</div>

                    <p className="text-muted-foreground leading-relaxed">
                        Leading the charge in prompt engineering and AI model interaction strategies.
                        Developing complex prompting chains to solve novel business problems.
                    </p>
                </div>

                {/* Placeholder for future entries */}
                <div className="relative pl-8 border-l-2 border-muted/50">
                    <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-background border-2 border-muted" />
                    <p className="text-muted-foreground italic">More history loading...</p>
                </div>
            </div>
        </section>
    );
}
