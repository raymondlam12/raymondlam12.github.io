"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";

export default function CursorChaser() {
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const [isVisible, setIsVisible] = useState(false);
    const [isMoving, setIsMoving] = useState(false);

    // Refs for animation loop
    const cursorRef = useRef({ x: 0, y: 0 });
    const positionRef = useRef({ x: 0, y: 0 });
    const requestRef = useRef<number>(0);
    const frameRef = useRef(0);
    const lastTimeRef = useRef(0);
    const hideTimeoutRef = useRef<NodeJS.Timeout>(null);

    useEffect(() => {
        // Initial cursor position (center of screen to avoid jump)
        if (typeof window !== "undefined") {
            cursorRef.current = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
            positionRef.current = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
        }

        const handleMouseMove = (e: MouseEvent) => {
            cursorRef.current = { x: e.clientX, y: e.clientY };
            setIsVisible(true);
            setIsMoving(true);

            // Clear existing timeout
            if (hideTimeoutRef.current) clearTimeout(hideTimeoutRef.current);

            // Set timeout to hide if mouse stops
            hideTimeoutRef.current = setTimeout(() => {
                setIsMoving(false);
                setIsVisible(false);
            }, 500); // 500ms timeout
        };

        window.addEventListener("mousemove", handleMouseMove);

        const animate = (time: number) => {
            const dx = cursorRef.current.x - positionRef.current.x;
            const dy = cursorRef.current.y - positionRef.current.y;

            const easing = 0.1;

            positionRef.current.x += dx * easing;
            positionRef.current.y += dy * easing;

            setPosition({ x: positionRef.current.x, y: positionRef.current.y });

            const distance = Math.sqrt(dx * dx + dy * dy);

            if (distance > 0.1) {
                const speedMultiplier = Math.min(Math.max(distance / 5, 1), 6);

                if (time - lastTimeRef.current > 80 / speedMultiplier) {
                    frameRef.current = (frameRef.current + 1) % 8;
                    lastTimeRef.current = time;
                }
            }

            requestRef.current = requestAnimationFrame(animate);
        };

        requestRef.current = requestAnimationFrame(animate);

        return () => {
            window.removeEventListener("mousemove", handleMouseMove);
            cancelAnimationFrame(requestRef.current);
            if (hideTimeoutRef.current) clearTimeout(hideTimeoutRef.current);
        };
    }, []);

    if (!isVisible) return null;

    // Configuration for "tall/proportionate" sprite (Half size: 60x100)
    // Adjusted: 50x100 visual size to match frame width and avoid next-frame bleed
    const targetFrameWidth = 50;
    const targetFrameHeight = 100;

    const naturalFrameWidth = 128; // 1024 / 8
    const naturalTotalWidth = 1024;
    const naturalTotalHeight = 1024;

    const scale = targetFrameWidth / naturalFrameWidth;

    const renderedTotalWidth = naturalTotalWidth * scale;
    const renderedTotalHeight = naturalTotalHeight * scale;

    // Shift image DOWN to reveal head (reduce offset)
    const verticalCorrection = 25;
    const topOffset = ((renderedTotalHeight - targetFrameHeight) / 2) - verticalCorrection;

    return (
        <div
            className="fixed pointer-events-none z-50 mix-blend-multiply dark:mix-blend-screen dark:invert"
            style={{
                left: position.x,
                top: position.y,
                transform: "translate(-50%, -50%)",
            }}
        >
            <div
                className="overflow-hidden relative"
                style={{
                    width: `${targetFrameWidth}px`,
                    height: `${targetFrameHeight}px`,
                }}
            >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                    src="/stick-figure-tall-run.png"
                    alt="Running Stick Figure"
                    style={{
                        width: `${renderedTotalWidth}px`,
                        height: "auto",
                        maxWidth: "none",
                        transform: `translate(-${frameRef.current * targetFrameWidth}px, -${topOffset}px)`,
                        display: "block",
                    }}
                />
            </div>
        </div>
    );
}
